﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmYourStyleOptions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmYourStyleOptions))
        Me._CustomFootwearDatabase__1_DataSet1 = New Your_Style_project1._CustomFootwearDatabase__1_DataSet()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblVintage = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.rdoQuarter = New System.Windows.Forms.RadioButton()
        Me.rdoVamp = New System.Windows.Forms.RadioButton()
        Me.rdoEyestay = New System.Windows.Forms.RadioButton()
        Me.rdoHeelTab = New System.Windows.Forms.RadioButton()
        Me.rdoHeelBaCounter = New System.Windows.Forms.RadioButton()
        Me.rdoLaces = New System.Windows.Forms.RadioButton()
        Me.rdoLogo = New System.Windows.Forms.RadioButton()
        Me.rdoText = New System.Windows.Forms.RadioButton()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.RadioButton10 = New System.Windows.Forms.RadioButton()
        Me.RadioButton11 = New System.Windows.Forms.RadioButton()
        CType(Me._CustomFootwearDatabase__1_DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        '_CustomFootwearDatabase__1_DataSet1
        '
        Me._CustomFootwearDatabase__1_DataSet1.DataSetName = "_CustomFootwearDatabase__1_DataSet"
        Me._CustomFootwearDatabase__1_DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(22, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(601, 96)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblVintage
        '
        Me.lblVintage.AutoSize = True
        Me.lblVintage.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVintage.Location = New System.Drawing.Point(257, 127)
        Me.lblVintage.Name = "lblVintage"
        Me.lblVintage.Size = New System.Drawing.Size(71, 20)
        Me.lblVintage.TabIndex = 1
        Me.lblVintage.Text = "Vintage"
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(239, 160)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 50)
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'rdoQuarter
        '
        Me.rdoQuarter.AutoSize = True
        Me.rdoQuarter.Location = New System.Drawing.Point(62, 268)
        Me.rdoQuarter.Name = "rdoQuarter"
        Me.rdoQuarter.Size = New System.Drawing.Size(60, 17)
        Me.rdoQuarter.TabIndex = 3
        Me.rdoQuarter.TabStop = True
        Me.rdoQuarter.Text = "Quar&ter"
        Me.rdoQuarter.UseVisualStyleBackColor = True
        '
        'rdoVamp
        '
        Me.rdoVamp.AutoSize = True
        Me.rdoVamp.Location = New System.Drawing.Point(62, 329)
        Me.rdoVamp.Name = "rdoVamp"
        Me.rdoVamp.Size = New System.Drawing.Size(52, 17)
        Me.rdoVamp.TabIndex = 4
        Me.rdoVamp.TabStop = True
        Me.rdoVamp.Text = "Va&mp"
        Me.rdoVamp.UseVisualStyleBackColor = True
        '
        'rdoEyestay
        '
        Me.rdoEyestay.AutoSize = True
        Me.rdoEyestay.Location = New System.Drawing.Point(171, 254)
        Me.rdoEyestay.Name = "rdoEyestay"
        Me.rdoEyestay.Size = New System.Drawing.Size(62, 17)
        Me.rdoEyestay.TabIndex = 5
        Me.rdoEyestay.TabStop = True
        Me.rdoEyestay.Text = "Eye&stay"
        Me.rdoEyestay.UseVisualStyleBackColor = True
        '
        'rdoHeelTab
        '
        Me.rdoHeelTab.AutoSize = True
        Me.rdoHeelTab.Location = New System.Drawing.Point(171, 309)
        Me.rdoHeelTab.Name = "rdoHeelTab"
        Me.rdoHeelTab.Size = New System.Drawing.Size(69, 17)
        Me.rdoHeelTab.TabIndex = 6
        Me.rdoHeelTab.TabStop = True
        Me.rdoHeelTab.Text = "H&eel Tap"
        Me.rdoHeelTab.UseVisualStyleBackColor = True
        '
        'rdoHeelBaCounter
        '
        Me.rdoHeelBaCounter.AutoSize = True
        Me.rdoHeelBaCounter.Location = New System.Drawing.Point(171, 364)
        Me.rdoHeelBaCounter.Name = "rdoHeelBaCounter"
        Me.rdoHeelBaCounter.Size = New System.Drawing.Size(117, 17)
        Me.rdoHeelBaCounter.TabIndex = 7
        Me.rdoHeelBaCounter.TabStop = True
        Me.rdoHeelBaCounter.Text = "Heel/B&ack Counter"
        Me.rdoHeelBaCounter.UseVisualStyleBackColor = True
        '
        'rdoLaces
        '
        Me.rdoLaces.AutoSize = True
        Me.rdoLaces.Location = New System.Drawing.Point(348, 268)
        Me.rdoLaces.Name = "rdoLaces"
        Me.rdoLaces.Size = New System.Drawing.Size(54, 17)
        Me.rdoLaces.TabIndex = 8
        Me.rdoLaces.TabStop = True
        Me.rdoLaces.Text = "Laces"
        Me.rdoLaces.UseVisualStyleBackColor = True
        '
        'rdoLogo
        '
        Me.rdoLogo.AutoSize = True
        Me.rdoLogo.Location = New System.Drawing.Point(348, 318)
        Me.rdoLogo.Name = "rdoLogo"
        Me.rdoLogo.Size = New System.Drawing.Size(49, 17)
        Me.rdoLogo.TabIndex = 9
        Me.rdoLogo.TabStop = True
        Me.rdoLogo.Text = "Logo"
        Me.rdoLogo.UseVisualStyleBackColor = True
        '
        'rdoText
        '
        Me.rdoText.AutoSize = True
        Me.rdoText.Location = New System.Drawing.Point(348, 364)
        Me.rdoText.Name = "rdoText"
        Me.rdoText.Size = New System.Drawing.Size(147, 17)
        Me.rdoText.TabIndex = 10
        Me.rdoText.TabStop = True
        Me.rdoText.Text = "Text(Up to 10 Characters)"
        Me.rdoText.UseVisualStyleBackColor = True
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Location = New System.Drawing.Point(533, 254)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(90, 17)
        Me.RadioButton9.TabIndex = 11
        Me.RadioButton9.TabStop = True
        Me.RadioButton9.Text = "RadioButton9"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'RadioButton10
        '
        Me.RadioButton10.AutoSize = True
        Me.RadioButton10.Location = New System.Drawing.Point(533, 309)
        Me.RadioButton10.Name = "RadioButton10"
        Me.RadioButton10.Size = New System.Drawing.Size(96, 17)
        Me.RadioButton10.TabIndex = 12
        Me.RadioButton10.TabStop = True
        Me.RadioButton10.Text = "RadioButton10"
        Me.RadioButton10.UseVisualStyleBackColor = True
        '
        'RadioButton11
        '
        Me.RadioButton11.AutoSize = True
        Me.RadioButton11.Location = New System.Drawing.Point(533, 364)
        Me.RadioButton11.Name = "RadioButton11"
        Me.RadioButton11.Size = New System.Drawing.Size(96, 17)
        Me.RadioButton11.TabIndex = 13
        Me.RadioButton11.TabStop = True
        Me.RadioButton11.Text = "RadioButton11"
        Me.RadioButton11.UseVisualStyleBackColor = True
        '
        'frmYourStyleOptions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ClientSize = New System.Drawing.Size(654, 401)
        Me.Controls.Add(Me.RadioButton11)
        Me.Controls.Add(Me.RadioButton10)
        Me.Controls.Add(Me.RadioButton9)
        Me.Controls.Add(Me.rdoText)
        Me.Controls.Add(Me.rdoLogo)
        Me.Controls.Add(Me.rdoLaces)
        Me.Controls.Add(Me.rdoHeelBaCounter)
        Me.Controls.Add(Me.rdoHeelTab)
        Me.Controls.Add(Me.rdoEyestay)
        Me.Controls.Add(Me.rdoVamp)
        Me.Controls.Add(Me.rdoQuarter)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.lblVintage)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmYourStyleOptions"
        Me.Text = "Your Style Options"
        CType(Me._CustomFootwearDatabase__1_DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents _CustomFootwearDatabase__1_DataSet1 As _CustomFootwearDatabase__1_DataSet
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblVintage As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents rdoQuarter As RadioButton
    Friend WithEvents rdoVamp As RadioButton
    Friend WithEvents rdoEyestay As RadioButton
    Friend WithEvents rdoHeelTab As RadioButton
    Friend WithEvents rdoHeelBaCounter As RadioButton
    Friend WithEvents rdoLaces As RadioButton
    Friend WithEvents rdoLogo As RadioButton
    Friend WithEvents rdoText As RadioButton
    Friend WithEvents RadioButton9 As RadioButton
    Friend WithEvents RadioButton10 As RadioButton
    Friend WithEvents RadioButton11 As RadioButton
End Class
