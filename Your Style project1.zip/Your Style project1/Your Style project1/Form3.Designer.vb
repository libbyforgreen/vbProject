﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form3))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblClassic = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.rdoQuarter3 = New System.Windows.Forms.RadioButton()
        Me.rdoVamp3 = New System.Windows.Forms.RadioButton()
        Me.rdoEyestay3 = New System.Windows.Forms.RadioButton()
        Me.rdoHeelTab3 = New System.Windows.Forms.RadioButton()
        Me.rdoHelbaccounter = New System.Windows.Forms.RadioButton()
        Me.rdoLaces3 = New System.Windows.Forms.RadioButton()
        Me.rdoLogo3 = New System.Windows.Forms.RadioButton()
        Me.rdoTextto10 = New System.Windows.Forms.RadioButton()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(55, 23)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(523, 91)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblClassic
        '
        Me.lblClassic.AutoSize = True
        Me.lblClassic.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassic.Location = New System.Drawing.Point(277, 135)
        Me.lblClassic.Name = "lblClassic"
        Me.lblClassic.Size = New System.Drawing.Size(66, 20)
        Me.lblClassic.TabIndex = 1
        Me.lblClassic.Text = "Classic"
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(264, 158)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 50)
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'rdoQuarter3
        '
        Me.rdoQuarter3.AutoSize = True
        Me.rdoQuarter3.Location = New System.Drawing.Point(55, 279)
        Me.rdoQuarter3.Name = "rdoQuarter3"
        Me.rdoQuarter3.Size = New System.Drawing.Size(60, 17)
        Me.rdoQuarter3.TabIndex = 3
        Me.rdoQuarter3.TabStop = True
        Me.rdoQuarter3.Text = "Quarter"
        Me.rdoQuarter3.UseVisualStyleBackColor = True
        '
        'rdoVamp3
        '
        Me.rdoVamp3.AutoSize = True
        Me.rdoVamp3.Location = New System.Drawing.Point(58, 338)
        Me.rdoVamp3.Name = "rdoVamp3"
        Me.rdoVamp3.Size = New System.Drawing.Size(52, 17)
        Me.rdoVamp3.TabIndex = 4
        Me.rdoVamp3.TabStop = True
        Me.rdoVamp3.Text = "Vamp"
        Me.rdoVamp3.UseVisualStyleBackColor = True
        '
        'rdoEyestay3
        '
        Me.rdoEyestay3.AutoSize = True
        Me.rdoEyestay3.Location = New System.Drawing.Point(58, 392)
        Me.rdoEyestay3.Name = "rdoEyestay3"
        Me.rdoEyestay3.Size = New System.Drawing.Size(62, 17)
        Me.rdoEyestay3.TabIndex = 5
        Me.rdoEyestay3.TabStop = True
        Me.rdoEyestay3.Text = "Eyestay"
        Me.rdoEyestay3.UseVisualStyleBackColor = True
        '
        'rdoHeelTab3
        '
        Me.rdoHeelTab3.AutoSize = True
        Me.rdoHeelTab3.Location = New System.Drawing.Point(213, 279)
        Me.rdoHeelTab3.Name = "rdoHeelTab3"
        Me.rdoHeelTab3.Size = New System.Drawing.Size(69, 17)
        Me.rdoHeelTab3.TabIndex = 6
        Me.rdoHeelTab3.TabStop = True
        Me.rdoHeelTab3.Text = "Heel Tab"
        Me.rdoHeelTab3.UseVisualStyleBackColor = True
        '
        'rdoHelbaccounter
        '
        Me.rdoHelbaccounter.AutoSize = True
        Me.rdoHelbaccounter.Location = New System.Drawing.Point(213, 338)
        Me.rdoHelbaccounter.Name = "rdoHelbaccounter"
        Me.rdoHelbaccounter.Size = New System.Drawing.Size(117, 17)
        Me.rdoHelbaccounter.TabIndex = 7
        Me.rdoHelbaccounter.TabStop = True
        Me.rdoHelbaccounter.Text = "Heel/Back Counter"
        Me.rdoHelbaccounter.UseVisualStyleBackColor = True
        '
        'rdoLaces3
        '
        Me.rdoLaces3.AutoSize = True
        Me.rdoLaces3.Location = New System.Drawing.Point(213, 392)
        Me.rdoLaces3.Name = "rdoLaces3"
        Me.rdoLaces3.Size = New System.Drawing.Size(54, 17)
        Me.rdoLaces3.TabIndex = 8
        Me.rdoLaces3.TabStop = True
        Me.rdoLaces3.Text = "Laces"
        Me.rdoLaces3.UseVisualStyleBackColor = True
        '
        'rdoLogo3
        '
        Me.rdoLogo3.AutoSize = True
        Me.rdoLogo3.Location = New System.Drawing.Point(370, 270)
        Me.rdoLogo3.Name = "rdoLogo3"
        Me.rdoLogo3.Size = New System.Drawing.Size(49, 17)
        Me.rdoLogo3.TabIndex = 9
        Me.rdoLogo3.TabStop = True
        Me.rdoLogo3.Text = "Logo"
        Me.rdoLogo3.UseVisualStyleBackColor = True
        '
        'rdoTextto10
        '
        Me.rdoTextto10.AutoSize = True
        Me.rdoTextto10.Location = New System.Drawing.Point(370, 338)
        Me.rdoTextto10.Name = "rdoTextto10"
        Me.rdoTextto10.Size = New System.Drawing.Size(147, 17)
        Me.rdoTextto10.TabIndex = 10
        Me.rdoTextto10.TabStop = True
        Me.rdoTextto10.Text = "Text(Up to 10 Characters)"
        Me.rdoTextto10.UseVisualStyleBackColor = True
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Location = New System.Drawing.Point(370, 392)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(90, 17)
        Me.RadioButton9.TabIndex = 11
        Me.RadioButton9.TabStop = True
        Me.RadioButton9.Text = "RadioButton9"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ClientSize = New System.Drawing.Size(632, 450)
        Me.Controls.Add(Me.RadioButton9)
        Me.Controls.Add(Me.rdoTextto10)
        Me.Controls.Add(Me.rdoLogo3)
        Me.Controls.Add(Me.rdoLaces3)
        Me.Controls.Add(Me.rdoHelbaccounter)
        Me.Controls.Add(Me.rdoHeelTab3)
        Me.Controls.Add(Me.rdoEyestay3)
        Me.Controls.Add(Me.rdoVamp3)
        Me.Controls.Add(Me.rdoQuarter3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.lblClassic)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form3"
        Me.Text = "Form3"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblClassic As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents rdoQuarter3 As RadioButton
    Friend WithEvents rdoVamp3 As RadioButton
    Friend WithEvents rdoEyestay3 As RadioButton
    Friend WithEvents rdoHeelTab3 As RadioButton
    Friend WithEvents rdoHelbaccounter As RadioButton
    Friend WithEvents rdoLaces3 As RadioButton
    Friend WithEvents rdoLogo3 As RadioButton
    Friend WithEvents rdoTextto10 As RadioButton
    Friend WithEvents RadioButton9 As RadioButton
End Class
