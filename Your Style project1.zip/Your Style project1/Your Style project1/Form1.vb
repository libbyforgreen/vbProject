﻿Public Class frmYourStyleOptions
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles rdoQuarter.CheckedChanged

    End Sub
End Class
