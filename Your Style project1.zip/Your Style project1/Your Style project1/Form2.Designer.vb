﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmYourStyOpt2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmYourStyOpt2))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblRetro = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.rdoQuarter2 = New System.Windows.Forms.RadioButton()
        Me.rdoVamp2 = New System.Windows.Forms.RadioButton()
        Me.rdoEyestay2 = New System.Windows.Forms.RadioButton()
        Me.rdoHeelTab2 = New System.Windows.Forms.RadioButton()
        Me.rdoHeelbaCounter = New System.Windows.Forms.RadioButton()
        Me.rdoLaces2 = New System.Windows.Forms.RadioButton()
        Me.rdoLogo2 = New System.Windows.Forms.RadioButton()
        Me.rdoUp210 = New System.Windows.Forms.RadioButton()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(29, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(613, 92)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblRetro
        '
        Me.lblRetro.AutoSize = True
        Me.lblRetro.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRetro.Location = New System.Drawing.Point(295, 138)
        Me.lblRetro.Name = "lblRetro"
        Me.lblRetro.Size = New System.Drawing.Size(54, 20)
        Me.lblRetro.TabIndex = 1
        Me.lblRetro.Text = "Retro"
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(273, 161)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 50)
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'rdoQuarter2
        '
        Me.rdoQuarter2.AutoSize = True
        Me.rdoQuarter2.Location = New System.Drawing.Point(96, 267)
        Me.rdoQuarter2.Name = "rdoQuarter2"
        Me.rdoQuarter2.Size = New System.Drawing.Size(60, 17)
        Me.rdoQuarter2.TabIndex = 3
        Me.rdoQuarter2.TabStop = True
        Me.rdoQuarter2.Text = "Quarter"
        Me.rdoQuarter2.UseVisualStyleBackColor = True
        '
        'rdoVamp2
        '
        Me.rdoVamp2.AutoSize = True
        Me.rdoVamp2.Location = New System.Drawing.Point(96, 317)
        Me.rdoVamp2.Name = "rdoVamp2"
        Me.rdoVamp2.Size = New System.Drawing.Size(52, 17)
        Me.rdoVamp2.TabIndex = 4
        Me.rdoVamp2.TabStop = True
        Me.rdoVamp2.Text = "Vamp"
        Me.rdoVamp2.UseVisualStyleBackColor = True
        '
        'rdoEyestay2
        '
        Me.rdoEyestay2.AutoSize = True
        Me.rdoEyestay2.Location = New System.Drawing.Point(96, 368)
        Me.rdoEyestay2.Name = "rdoEyestay2"
        Me.rdoEyestay2.Size = New System.Drawing.Size(62, 17)
        Me.rdoEyestay2.TabIndex = 5
        Me.rdoEyestay2.TabStop = True
        Me.rdoEyestay2.Text = "Eyestay"
        Me.rdoEyestay2.UseVisualStyleBackColor = True
        '
        'rdoHeelTab2
        '
        Me.rdoHeelTab2.AutoSize = True
        Me.rdoHeelTab2.Location = New System.Drawing.Point(222, 267)
        Me.rdoHeelTab2.Name = "rdoHeelTab2"
        Me.rdoHeelTab2.Size = New System.Drawing.Size(69, 17)
        Me.rdoHeelTab2.TabIndex = 6
        Me.rdoHeelTab2.TabStop = True
        Me.rdoHeelTab2.Text = "Heel Tab"
        Me.rdoHeelTab2.UseVisualStyleBackColor = True
        '
        'rdoHeelbaCounter
        '
        Me.rdoHeelbaCounter.AutoSize = True
        Me.rdoHeelbaCounter.Location = New System.Drawing.Point(222, 317)
        Me.rdoHeelbaCounter.Name = "rdoHeelbaCounter"
        Me.rdoHeelbaCounter.Size = New System.Drawing.Size(117, 17)
        Me.rdoHeelbaCounter.TabIndex = 7
        Me.rdoHeelbaCounter.TabStop = True
        Me.rdoHeelbaCounter.Text = "Heel/Back Counter"
        Me.rdoHeelbaCounter.UseVisualStyleBackColor = True
        '
        'rdoLaces2
        '
        Me.rdoLaces2.AutoSize = True
        Me.rdoLaces2.Location = New System.Drawing.Point(222, 368)
        Me.rdoLaces2.Name = "rdoLaces2"
        Me.rdoLaces2.Size = New System.Drawing.Size(54, 17)
        Me.rdoLaces2.TabIndex = 8
        Me.rdoLaces2.TabStop = True
        Me.rdoLaces2.Text = "Laces"
        Me.rdoLaces2.UseVisualStyleBackColor = True
        '
        'rdoLogo2
        '
        Me.rdoLogo2.AutoSize = True
        Me.rdoLogo2.Location = New System.Drawing.Point(364, 267)
        Me.rdoLogo2.Name = "rdoLogo2"
        Me.rdoLogo2.Size = New System.Drawing.Size(49, 17)
        Me.rdoLogo2.TabIndex = 9
        Me.rdoLogo2.TabStop = True
        Me.rdoLogo2.Text = "Logo"
        Me.rdoLogo2.UseVisualStyleBackColor = True
        '
        'rdoUp210
        '
        Me.rdoUp210.AutoSize = True
        Me.rdoUp210.Location = New System.Drawing.Point(364, 317)
        Me.rdoUp210.Name = "rdoUp210"
        Me.rdoUp210.Size = New System.Drawing.Size(147, 17)
        Me.rdoUp210.TabIndex = 10
        Me.rdoUp210.TabStop = True
        Me.rdoUp210.Text = "Text(Up to 10 Characters)"
        Me.rdoUp210.UseVisualStyleBackColor = True
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Location = New System.Drawing.Point(364, 368)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(90, 17)
        Me.RadioButton9.TabIndex = 11
        Me.RadioButton9.TabStop = True
        Me.RadioButton9.Text = "RadioButton9"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'frmYourStyOpt2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ClientSize = New System.Drawing.Size(661, 450)
        Me.Controls.Add(Me.RadioButton9)
        Me.Controls.Add(Me.rdoUp210)
        Me.Controls.Add(Me.rdoLogo2)
        Me.Controls.Add(Me.rdoLaces2)
        Me.Controls.Add(Me.rdoHeelbaCounter)
        Me.Controls.Add(Me.rdoHeelTab2)
        Me.Controls.Add(Me.rdoEyestay2)
        Me.Controls.Add(Me.rdoVamp2)
        Me.Controls.Add(Me.rdoQuarter2)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.lblRetro)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "frmYourStyOpt2"
        Me.Text = "Your Style Options2"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblRetro As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents rdoQuarter2 As RadioButton
    Friend WithEvents rdoVamp2 As RadioButton
    Friend WithEvents rdoEyestay2 As RadioButton
    Friend WithEvents rdoHeelTab2 As RadioButton
    Friend WithEvents rdoHeelbaCounter As RadioButton
    Friend WithEvents rdoLaces2 As RadioButton
    Friend WithEvents rdoLogo2 As RadioButton
    Friend WithEvents rdoUp210 As RadioButton
    Friend WithEvents RadioButton9 As RadioButton
End Class
